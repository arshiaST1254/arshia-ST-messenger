package com.arshia.st;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    static final String ADMIN = "09024205817";
    LinearLayout root, posts;
    EditText phone, message;
    SharedPreferences prefs;

    int dp(float v){ return (int)(v*getResources().getDisplayMetrics().density+0.5f); }
    TextView tv(String text,float size,int color){
        TextView t=new TextView(this); t.setText(text); t.setTextSize(size); t.setTextColor(color);
        t.setPadding(dp(4),dp(4),dp(4),dp(4)); return t;
    }
    GradientDrawable bg(int color,float radius){
        GradientDrawable g=new GradientDrawable(); g.setColor(color); g.setCornerRadius(dp(radius)); return g;
    }
    Button btn(String text){
        Button b=new Button(this); b.setText(text); b.setTextColor(Color.WHITE); b.setTextSize(16);
        b.setAllCaps(false); b.setBackground(bg(Color.rgb(81,70,229),15)); b.setPadding(dp(10),dp(5),dp(10),dp(5));
        return b;
    }
    @Override public void onCreate(Bundle b){ super.onCreate(b); prefs=getSharedPreferences("arshia",0); showLogin(); }

    void base(){ root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.rgb(246,248,251)); setContentView(root); }

    void showLogin(){
        base();
        Space top=new Space(this); root.addView(top,new LinearLayout.LayoutParams(1,dp(70)));
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setGravity(Gravity.CENTER_HORIZONTAL);
        box.setPadding(dp(24),dp(28),dp(24),dp(28)); box.setBackground(bg(Color.WHITE,28));
        LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,-2); bp.setMargins(dp(22),0,dp(22),0); root.addView(box,bp);

        TextView logo=tv("ST",25,Color.WHITE); logo.setGravity(Gravity.CENTER); logo.setTypeface(null,1);
        GradientDrawable lg=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{Color.rgb(81,70,229),Color.rgb(8,181,213)}); lg.setCornerRadius(dp(24)); logo.setBackground(lg);
        box.addView(logo,new LinearLayout.LayoutParams(dp(82),dp(82)));

        TextView title=tv("arshia ST",29,Color.rgb(24,32,51)); title.setTypeface(null,1); title.setGravity(Gravity.CENTER);
        box.addView(title,new LinearLayout.LayoutParams(-1,-2));
        TextView info=tv("به کانال رسمی arshia ST خوش آمدی.\nشماره موبایل خودت را وارد کن.",16,Color.rgb(120,130,148)); info.setGravity(Gravity.CENTER); box.addView(info);

        phone=new EditText(this); phone.setHint("09123456789"); phone.setInputType(3); phone.setTextSize(17); phone.setPadding(dp(14),0,dp(14),0);
        box.addView(phone,new LinearLayout.LayoutParams(-1,dp(58)));
        Button enter=btn("ورود به کانال"); LinearLayout.LayoutParams eb=new LinearLayout.LayoutParams(-1,dp(58)); eb.setMargins(0,dp(12),0,0); box.addView(enter,eb);
        box.addView(tv("نسخه ۱ • مدیر اصلی: شماره تعیین‌شده در پروژه",12,Color.rgb(150,157,170)));
        enter.setOnClickListener(v->login());
    }

    String norm(String s){ return s.replace(" ","").replace("-",""); }
    void login(){
        String p=norm(phone.getText().toString());
        if(p.length()<7){ Toast.makeText(this,"شماره موبایل را درست وارد کن.",Toast.LENGTH_SHORT).show(); return; }
        prefs.edit().putString("phone",p).apply();
        ((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(phone.getWindowToken(),0);
        if(ADMIN.equals(p)) showAdmin(); else showChannel();
    }

    void header(String title,String sub){
        LinearLayout h=new LinearLayout(this); h.setPadding(dp(15),dp(10),dp(15),dp(10)); h.setGravity(Gravity.CENTER_VERTICAL);
        TextView av=tv(title.equals("مدیریت arshia ST")?"👑":"ST",18,Color.WHITE); av.setGravity(Gravity.CENTER); av.setBackground(bg(Color.rgb(81,70,229),50));
        h.addView(av,new LinearLayout.LayoutParams(dp(48),dp(48)));
        LinearLayout tx=new LinearLayout(this); tx.setOrientation(LinearLayout.VERTICAL); tx.setPadding(dp(10),0,0,0);
        TextView a=tv(title,19,Color.rgb(24,32,51)); a.setTypeface(null,1); tx.addView(a);
        tx.addView(tv(sub,11,Color.rgb(125,135,151))); h.addView(tx,new LinearLayout.LayoutParams(0,-2,1));
        h.setBackgroundColor(Color.WHITE); root.addView(h,new LinearLayout.LayoutParams(-1,dp(70)));
    }

    void showChannel(){
        base(); header("arshia ST","کانال رسمی • فقط مدیر می‌تواند پیام بفرستد");
        ScrollView sv=new ScrollView(this); LinearLayout c=new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setPadding(dp(14),dp(14),dp(14),dp(20));
        TextView welcome=tv("🎉  به کانال arshia ST خوش آمدی!",18,Color.WHITE); welcome.setPadding(dp(18),dp(18),dp(18),dp(18)); welcome.setBackground(bg(Color.rgb(81,70,229),20));
        c.addView(welcome); posts=new LinearLayout(this); posts.setOrientation(LinearLayout.VERTICAL); c.addView(posts);
        loadPosts(); sv.addView(c); root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
    }

    void addPost(String text){
        LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(dp(16),dp(14),dp(16),dp(14)); card.setBackground(bg(Color.WHITE,18));
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2); cp.setMargins(0,dp(12),0,0);
        TextView meta=tv("arshia ST    •    اکنون",11,Color.rgb(135,145,160)); card.addView(meta);
        TextView body=tv(text,15,Color.rgb(45,54,70)); body.setPadding(0,dp(8),0,0); card.addView(body);
        posts.addView(card,0,cp);
    }
    void loadPosts(){
        String all=prefs.getString("posts","");
        if(all.isEmpty()) addPost("به کانال arshia ST خوش آمدید! اینجا اعضا فقط پیام‌ها را می‌بینند و نمی‌توانند پیام بفرستند.");
        else for(String s:all.split("\\n---\\n")) if(!s.isEmpty()) addPost(s);
    }

    void showAdmin(){
        base(); header("مدیریت arshia ST","👑 مدیر اصلی");
        LinearLayout c=new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setPadding(dp(14),dp(14),dp(14),dp(20));
        TextView label=tv("ارسال پیام جدید",19,Color.rgb(24,32,51)); label.setTypeface(null,1); c.addView(label);
        message=new EditText(this); message.setHint("پیامت را بنویس..."); message.setGravity(Gravity.TOP); message.setPadding(dp(14),dp(14),dp(14),dp(14)); message.setMinHeight(dp(130));
        c.addView(message,new LinearLayout.LayoutParams(-1,dp(145)));
        Button pub=btn("انتشار پیام"); LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(-1,dp(58)); pp.setMargins(0,dp(12),0,0); c.addView(pub,pp);
        Button view=btn("مشاهده کانال"); view.setBackground(bg(Color.rgb(30,36,50),15)); LinearLayout.LayoutParams vp=new LinearLayout.LayoutParams(-1,dp(54)); vp.setMargins(0,dp(8),0,0); c.addView(view,vp);
        c.addView(tv("\nشماره مدیر اصلی: "+ADMIN+"\nاین نسخه برای تست روی یک دستگاه است؛ برای ارسال واقعی به همه کاربران، Firebase/سرور لازم است.",13,Color.rgb(125,135,151)));
        root.addView(c,new LinearLayout.LayoutParams(-1,-2));
        pub.setOnClickListener(v->publish()); view.setOnClickListener(v->showChannel());
    }
    void publish(){
        String t=message.getText().toString().trim(); if(t.isEmpty()){Toast.makeText(this,"پیام خالی است.",Toast.LENGTH_SHORT).show();return;}
        String old=prefs.getString("posts","");
        prefs.edit().putString("posts",t+(old.isEmpty()?"":"\n---\n"+old)).apply();
        message.setText(""); Toast.makeText(this,"پیام منتشر شد.",Toast.LENGTH_SHORT).show();
    }
}